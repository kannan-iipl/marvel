from django.shortcuts import render
from career.models import CareerDetails
from django.http import HttpResponseRedirect

# Create your views here.
def index(request):
    return render(request,'index.html')
    

def  saveForm(request):
    #POST Datas
    name          = request.POST.get('name', '')
    emailAddress  = request.POST.get('emailAddress', '')
    address       = request.POST.get('address', '')
    contactNumber = request.POST.get('contactNumber', '')
    #Insert Datas
    C = CareerDetails(name=name,contactNumber=contactNumber,emailAddress=emailAddress,address=address)
    C.save()
    
    URL = "/career/"
    return HttpResponseRedirect(URL)
    
