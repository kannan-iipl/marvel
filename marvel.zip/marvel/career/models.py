from django.db import models

# Create your models here.

# Model for Vendor
class CareerDetails(models.Model):
    # Meta fields
    class Meta:  
        verbose_name_plural = "Career Details"
    # fields     
    name    = models.CharField(verbose_name='Name',max_length=100, default='', blank=False)
    contactNumber = models.CharField(verbose_name='Mobile Number',null=True, max_length=10, blank=False) 
    emailAddress  = models.EmailField(verbose_name='Email Id',null=True, max_length=50, blank=True,  default='')
    address       = models.CharField(verbose_name='Address',null=True, max_length=255,blank=False)
    def __str__(self):
        return self.name